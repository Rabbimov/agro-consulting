import { Brand } from "@/types/brand";
import Image from "next/image";
import brandsData from "./brandsData";
import SectionTitle from "../Common/SectionTitle";

const Brands = () => {
  return (
    <section className="pt-16">
      <div className="container">
        <SectionTitle title="Наши партнеры" paragraph="" center />
        <div className="-mx-4 flex flex-wrap">
          <div className="w-full px-4">
            <div className="flex flex-wrap items-center justify-center rounded-lg bg-gray-light px-8 py-0 dark:bg-gray-dark sm:px-10 md:px-[50px]  xl:px-[50px] 2xl:px-[70px]">
              {brandsData.map((brand) => (
                <SingleBrand key={brand.id} brand={brand} />
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Brands;

const SingleBrand = ({ brand }: { brand: Brand }) => {
  const { href, image, imageLight, name } = brand;

  return (
    <div className="flex w-1/2 items-center justify-center px-8 py-[30px] transition-all duration-500 hover:scale-125 sm:w-1/2 md:w-1/3 lg:w-1/4 xl:w-1/6 ">
      <div className="relative aspect-square w-full opacity-70 transition hover:opacity-100 dark:opacity-60 dark:hover:opacity-100">
        <Image src={image} alt={name} fill className="w-full dark:hidden" />
        <Image
          src={imageLight}
          alt={name}
          fill
          className="hidden w-full dark:block"
        />
      </div>
    </div>
  );
};
