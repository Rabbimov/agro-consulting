import AboutSectionFirst from "@/components/About/AboutSectionFirst";
import AboutSectionOne from "@/components/About/AboutSectionOne";
// import AboutSectionOne from "@/components/About/AboutSectionOne";
import AboutSectionSecond from "@/components/About/AboutSectionSecond";
import AboutSectionTwo from "@/components/About/AboutSectionTwo";
import Blog from "@/components/Blog";
import Brands from "@/components/Brands";
import ScrollUp from "@/components/Common/ScrollUp";
// import Contact from "@/components/Contact";
import Features from "@/components/Features";
import Hero from "@/components/Hero";
import GalLeryCarousel from "@/components/ImageCarousel/GalleryCarousel";
// import Pricing from "@/components/Pricing";
// import Testimonials from "@/components/Testimonials";
// import Video from "@/components/Video";
import { Metadata } from "next";

export const metadata: Metadata = {
  title: "Free Next.js Template for Startup and SaaS",
  description: "This is Home for Startup Nextjs Template",
  // other metadata
};

export default function Home() {
  return (
    <>
      <ScrollUp />
      <Hero />
      <Features />
      <Blog />
      <AboutSectionFirst />
      <AboutSectionSecond />
      <Brands />
      <GalLeryCarousel />
      <AboutSectionOne />
      <AboutSectionTwo />

      {/* <Video /> */}
      {/* <Testimonials /> */}
      {/* <Pricing /> */}
      {/* <Contact /> */}
    </>
  );
}
